/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c3;

/* USER CODE BEGIN PV */

uint8_t data[19];

float sensor_temp = 0.0f;
float pixel_temp[8];

uint8_t pec_ok = 0;
uint8_t calculated_pec = 0;

HAL_StatusTypeDef status;
HAL_StatusTypeDef init_status;

uint8_t received_pec = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t calc_crc(uint8_t data)
{
    for (int i = 0; i < 8; i++)
    {
        uint8_t temp = data;
        data <<= 1;

        if (temp & 0x80)
        {
            data ^= 0x07;
        }
    }

    return data;
}

uint8_t check_pec(uint8_t *data)
{
    uint8_t crc;

    // Slave address + Write
    crc = calc_crc(0x14);

    // Temperaturkommando
    crc = calc_crc(0x4C ^ crc);

    // Slave address + Read
    crc = calc_crc(0x15 ^ crc);

    // De 18 mottatte databytene
    for (int i = 0; i < 18; i++)
    {
        crc = calc_crc(data[i] ^ crc);
    }

    calculated_pec = crc;

    // Sammenlign beregnet PEC med mottatt PEC
    return (crc == data[18]);
}
HAL_StatusTypeDef D6T_Init(void)
{
    HAL_StatusTypeDef status;

    uint8_t cmd1[] = {0x02, 0x00, 0x01, 0xEE};
    uint8_t cmd2[] = {0x05, 0x90, 0x3A, 0xB8};
    uint8_t cmd3[] = {0x03, 0x00, 0x03, 0x8B};
    uint8_t cmd4[] = {0x03, 0x00, 0x07, 0x97};
    uint8_t cmd5[] = {0x02, 0x00, 0x00, 0xE9};

    status = HAL_I2C_Master_Transmit(&hi2c3, 0x0A << 1,
                                     cmd1, sizeof(cmd1), 100);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Master_Transmit(&hi2c3, 0x0A << 1,
                                     cmd2, sizeof(cmd2), 100);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Master_Transmit(&hi2c3, 0x0A << 1,
                                     cmd3, sizeof(cmd3), 100);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Master_Transmit(&hi2c3, 0x0A << 1,
                                     cmd4, sizeof(cmd4), 100);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Master_Transmit(&hi2c3, 0x0A << 1,
                                     cmd5, sizeof(cmd5), 100);

    return status;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C3_Init();
  /* USER CODE BEGIN 2 */

  HAL_Delay(100);

  init_status = D6T_Init();

  HAL_Delay(500);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  status = HAL_I2C_Mem_Read(
	          &hi2c3,
	          0x0A << 1,             // D6T I2C-adresse
	          0x4C,                  // Temperaturkommando
	          I2C_MEMADD_SIZE_8BIT,
	          data,
	          19,                    // 18 databytes + 1 PEC
	          100
	      );

	      if (status == HAL_OK)
	      {
	          received_pec = data[18];

	          pec_ok = check_pec(data);

	          // Intern sensortemperatur (PTAT)
	          int16_t raw_ptat =
	              (int16_t)(((uint16_t)data[1] << 8) | data[0]);

	          sensor_temp = raw_ptat / 10.0f;

	          for (int i = 0; i < 8; i++)
	          {
	              int index = 2 + (i * 2);

	              int16_t raw =
	                  (int16_t)(((uint16_t)data[index + 1] << 8)
	                            | data[index]);

	              pixel_temp[i] = raw / 5.0f;
	          }
	      }

	      HAL_Delay(500);
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = 0x00503D58;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
