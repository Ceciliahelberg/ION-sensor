/*
 * suspension.h
 *
 *  Created on: Mar 11, 2026
 *      Author: cecil
 */

#ifndef SENSORS_SUSPENSION_H
#define SENSORS_SUSPENSION_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

typedef enum {
    SUSPENSION_OK = 0,
    SUSPENSION_NOT_INIT,
    SUSPENSION_ADC_START_ERROR,
} Suspension_Status_t;

void Suspension_Init(ADC_HandleTypeDef *hadc);
/* Kalles fra ADC DMA callback (ISR-context) */
void Suspension_OnNewSample(uint16_t raw_ch6, uint16_t raw_ch7);

Suspension_Status_t Suspension_GetStatus(void);
uint16_t Suspension_GetRaw(uint8_t idx);   /* idx: 0 (PC0/CH6), 1 (PC1/CH7) */
int      Suspension_GetPosMm(uint8_t idx); /* mm (avrundet, fjorårs-lik) */


#endif /* INC_SUSPENSION_H_ */
