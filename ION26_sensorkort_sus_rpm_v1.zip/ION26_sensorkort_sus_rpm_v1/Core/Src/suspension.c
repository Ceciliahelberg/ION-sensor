/*
 * suspension.c
 *
 *  Created on: Mar 11, 2026
 *      Author: cecil
 */


#include "suspension.h"
#include "stm32g4xx_hal.h"

/* ===== Fjorårs-kalibrering (KAN MÅ OPPDATERES FOR DERES SENSOR/KRETS) ===== */
#define WSS_COUNTS_AT_0MM   3985u
#define WSS_COUNTS_AT_76MM  167u
#define WSS_MAX_MM          76.0f
#define WSS_MM_PER_COUNT    (WSS_MAX_MM / (float)(WSS_COUNTS_AT_0MM - WSS_COUNTS_AT_76MM))

static ADC_HandleTypeDef *s_hadc = NULL;
static Suspension_Status_t s_status = SUSPENSION_NOT_INIT;

static volatile uint16_t s_raw0 = 0; /* Rank1 -> CH6 -> PC0 */
static volatile uint16_t s_raw1 = 0; /* Rank2 -> CH7 -> PC1 */
static volatile int s_mm0 = 0;
static volatile int s_mm1 = 0;

static inline int counts_to_mm_rounded(uint16_t adc)
{
    float mm = ((float)WSS_COUNTS_AT_0MM - (float)adc) * WSS_MM_PER_COUNT;

    if (mm < 0.0f)              mm = 0.0f;
    else if (mm > WSS_MAX_MM)   mm = WSS_MAX_MM;

    return (int)(mm + 0.5f); /* nearest mm */
}

void Suspension_Init(ADC_HandleTypeDef *hadc)
{
    s_hadc = hadc;

    s_raw0 = 0;
    s_raw1 = 0;
    s_mm0  = 0;
    s_mm1  = 0;

    if (s_hadc == NULL)
    {
        s_status = SUSPENSION_NOT_INIT;
        return;
    }

    s_status = SUSPENSION_OK;
}

/* Kalles fra HAL_ADC_ConvCpltCallback() når DMA-buffer er full */
void Suspension_OnNewSample(uint16_t raw_ch6, uint16_t raw_ch7)
{
    if (s_status != SUSPENSION_OK)
        return;

    /* Lagre råverdier */
    s_raw0 = raw_ch6;
    s_raw1 = raw_ch7;

    /* Konverter til mm */
    s_mm0 = counts_to_mm_rounded(s_raw0);
    s_mm1 = counts_to_mm_rounded(s_raw1);
}

Suspension_Status_t Suspension_GetStatus(void)
{
    return s_status;
}

uint16_t Suspension_GetRaw(uint8_t idx)
{
    if (idx == 0) return s_raw0;
    if (idx == 1) return s_raw1;
    return 0;
}

int Suspension_GetPosMm(uint8_t idx)
{
    if (idx == 0) return s_mm0;
    if (idx == 1) return s_mm1;
    return 0;
}
